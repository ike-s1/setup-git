export const PRIVAT = 'PRIVAT ';
export const PUBLICK = 'PUBLICK ';
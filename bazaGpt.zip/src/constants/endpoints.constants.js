export const SERVER_ENDPOINT = process.env.REACT_APP_NETWORK === 'testnet'
    ? ""
    :"https://bazaapi.ivankravets.repl.co";
export const selectModal = (state) => state.user;

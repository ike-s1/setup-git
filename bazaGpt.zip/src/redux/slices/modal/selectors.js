
export const selectModal = (state) => state.modal;

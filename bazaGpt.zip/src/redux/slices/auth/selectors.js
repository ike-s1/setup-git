export const selectModal = (state) => state.auth;
